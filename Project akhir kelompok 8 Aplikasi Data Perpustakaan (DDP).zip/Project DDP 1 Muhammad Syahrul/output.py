from Perpustakaan import *

if __name__ == '__main__':
    root.title("Aplikasi Data Perpustakaan")
    root.geometry("700x500")
    root.resizable(FALSE,FALSE)
    if(isFirst("LIBRARY")):
        create_table()
    else:
        pass
    root.mainloop()
